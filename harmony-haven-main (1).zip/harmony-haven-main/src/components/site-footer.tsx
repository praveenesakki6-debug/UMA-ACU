import { Link } from "@tanstack/react-router";
import { Phone, MapPin, MessageCircle } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-gradient-warm border-t border-border/60">
      <div className="container mx-auto px-5 lg:px-8 py-14 grid gap-10 md:grid-cols-3">
        <div>
          <div className="font-display text-2xl font-semibold">Uma Acu Wellness</div>
          <p className="text-sm text-muted-foreground mt-2">
            T. Uma Maheshwari
            <br />
            BBA, D.Ac., M.Sc., Acu Therapist
          </p>
          <p className="text-xs italic text-muted-foreground mt-4 max-w-xs">
            “Natural Wellness Through Acu Therapy”
          </p>
        </div>

        <div>
          <h4 className="font-display text-lg mb-3">Visit Us</h4>
          <div className="flex items-start gap-2 text-sm text-muted-foreground">
            <MapPin className="w-4 h-4 mt-0.5 text-primary shrink-0" />
            <span>No. 22/13, Sanjay Gandhi Street, MGR Nagar, Chennai - 600078</span>
          </div>
          <a href="tel:8667563373" className="flex items-center gap-2 text-sm text-muted-foreground mt-2 hover:text-primary">
            <Phone className="w-4 h-4 text-primary" /> 8667563373
          </a>
          <a
            href="https://wa.me/918667563373"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 text-sm text-muted-foreground mt-2 hover:text-primary"
          >
            <MessageCircle className="w-4 h-4 text-primary" /> WhatsApp
          </a>
        </div>

        <div>
          <h4 className="font-display text-lg mb-3">Explore</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/" className="hover:text-primary">Home</Link></li>
            <li><Link to="/about" className="hover:text-primary">About</Link></li>
            <li><Link to="/treatments" className="hover:text-primary">Treatments</Link></li>
            <li><Link to="/track" className="hover:text-primary">Track My Treatment</Link></li>
            <li><Link to="/contact" className="hover:text-primary">Contact</Link></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border/60">
        <div className="container mx-auto px-5 lg:px-8 py-5 text-xs text-muted-foreground text-center max-w-3xl">
          <p>
            <strong>Disclaimer:</strong> This therapy is for wellness support. For serious medical
            conditions, consult a qualified medical doctor.
          </p>
          <p className="mt-2">© {new Date().getFullYear()} Uma Acu Wellness Clinic. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
