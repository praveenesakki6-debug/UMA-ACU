import { SiteHeader } from "./site-header";
import { SiteFooter } from "./site-footer";
import { MessageCircle } from "lucide-react";
import type { ReactNode } from "react";

export function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">{children}</main>
      <SiteFooter />

      <a
        href="https://wa.me/918667563373"
        target="_blank"
        rel="noreferrer"
        aria-label="WhatsApp"
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-soft hover:scale-105 transition-transform"
      >
        <MessageCircle className="w-7 h-7" />
      </a>
    </div>
  );
}
