import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { Activity, MessageSquareText, Heart, Sparkles, Leaf, Flower2, RotateCcw } from "lucide-react";

export const Route = createFileRoute("/treatments")({
  head: () => ({
    meta: [
      { title: "Treatments — Uma Acu Wellness" },
      { name: "description", content: "Explore our acupuncture and acu therapy services: pulse checking, pain relief support, wellness therapy, and more." },
    ],
  }),
  component: TreatmentsPage,
});

const treatments = [
  { icon: Sparkles, title: "Acupuncture Therapy", desc: "Gentle needle-based therapy guided by traditional principles." },
  { icon: MessageSquareText, title: "Acu Therapy Consultation", desc: "Personal consultation to discuss your wellness goals and concerns." },
  { icon: Activity, title: "Pulse / Naadi Checking", desc: "Traditional pulse assessment to understand your body's balance." },
  { icon: Heart, title: "Pain Relief Support", desc: "Supportive sessions for everyday aches and discomfort." },
  { icon: Leaf, title: "Stress & Relaxation Support", desc: "Calming sessions to ease tension and restore composure." },
  { icon: Flower2, title: "Wellness Therapy", desc: "Holistic care to support overall well-being and vitality." },
  { icon: RotateCcw, title: "Follow-up Sessions", desc: "Regular check-ins to track progress and adjust your plan." },
];

function TreatmentsPage() {
  return (
    <SiteLayout>
      <section className="bg-gradient-hero py-20">
        <div className="container mx-auto px-5 lg:px-8 text-center max-w-3xl">
          <div className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">Our Services</div>
          <h1 className="mt-3 font-display text-5xl md:text-6xl font-semibold">Treatments</h1>
          <p className="mt-4 text-muted-foreground">
            A range of natural therapies designed to support your wellness journey.
          </p>
        </div>
      </section>

      <section className="container mx-auto px-5 lg:px-8 py-16">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {treatments.map((t, i) => (
            <div key={i} className="group rounded-3xl bg-card border border-border/60 p-7 shadow-card hover:shadow-soft hover:-translate-y-1 transition-all">
              <div className="w-14 h-14 rounded-2xl bg-gradient-warm flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <t.icon className="w-7 h-7 text-primary" />
              </div>
              <h3 className="font-display text-2xl font-semibold">{t.title}</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{t.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 rounded-2xl bg-secondary/50 border border-border/60 p-6 text-sm text-muted-foreground text-center max-w-3xl mx-auto">
          All treatments are offered as wellness support. For serious medical conditions, please
          consult a qualified medical doctor.
        </div>
      </section>
    </SiteLayout>
  );
}
