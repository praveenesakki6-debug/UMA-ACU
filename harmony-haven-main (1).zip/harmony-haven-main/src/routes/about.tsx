import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { Heart, MessageSquareText, Activity } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About T. Uma Maheshwari — Uma Acu Wellness" },
      { name: "description", content: "Meet T. Uma Maheshwari, qualified Acu Therapist offering pulse-based checking and personal consultation in Chennai." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <SiteLayout>
      <section className="bg-gradient-hero py-20">
        <div className="container mx-auto px-5 lg:px-8 text-center max-w-3xl">
          <div className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">About the Therapist</div>
          <h1 className="mt-3 font-display text-5xl md:text-6xl font-semibold">T. Uma Maheshwari</h1>
          <p className="mt-3 text-muted-foreground">BBA, D.Ac., M.Sc., Acu Therapist</p>
        </div>
      </section>

      <section className="container mx-auto px-5 lg:px-8 py-16 grid lg:grid-cols-2 gap-12 items-start">
        <div className="rounded-3xl bg-gradient-warm border border-border/60 p-10 shadow-card">
          <div className="w-20 h-20 rounded-full bg-gradient-gold mx-auto flex items-center justify-center shadow-soft">
            <span className="font-display text-3xl font-bold text-gold-foreground">U</span>
          </div>
          <p className="mt-6 font-display text-2xl text-center italic text-primary">
            “Natural Wellness Through Acu Therapy”
          </p>
        </div>

        <div className="space-y-5 text-foreground/85 leading-relaxed">
          <p>
            With a heartfelt commitment to holistic care, T. Uma Maheshwari offers acupuncture and
            acu therapy in a calm, welcoming clinic in MGR Nagar, Chennai. Her practice is built
            around traditional pulse (naadi) checking and patient-focused, question-based
            consultations that take time to truly understand each person's well-being.
          </p>
          <p>
            Every session begins with careful listening — a chance to share concerns, daily habits,
            and lifestyle — followed by gentle pulse assessment. From there, a personalized
            treatment plan is created to support your wellness journey.
          </p>
          <p>
            The clinic provides acupuncture and acu therapy for{" "}
            <strong>wellness support, pain relief support, stress relaxation support, and
            follow-up care</strong>. Our approach is natural, gentle, and focused on supporting
            your body's own balance.
          </p>
        </div>
      </section>

      <section className="container mx-auto px-5 lg:px-8 pb-20">
        <div className="grid md:grid-cols-3 gap-5">
          {[
            { icon: Activity, title: "Pulse / Naadi Checking", desc: "Traditional pulse-based assessment to understand your body's signals." },
            { icon: MessageSquareText, title: "Question-based Consultation", desc: "Thoughtful, attentive conversation to guide your wellness plan." },
            { icon: Heart, title: "Caring, Personal Approach", desc: "Every patient is treated with warmth, respect, and care." },
          ].map((c, i) => (
            <div key={i} className="rounded-3xl bg-card border border-border/60 p-7 shadow-card">
              <div className="w-12 h-12 rounded-2xl bg-secondary flex items-center justify-center mb-4">
                <c.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display text-xl font-semibold">{c.title}</h3>
              <p className="text-sm text-muted-foreground mt-2">{c.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 rounded-2xl bg-secondary/50 border border-border/60 p-6 text-sm text-muted-foreground text-center max-w-3xl mx-auto">
          <strong>Please note:</strong> This therapy is for wellness support. For serious medical
          conditions, please consult a qualified medical doctor.
        </div>
      </section>
    </SiteLayout>
  );
}
