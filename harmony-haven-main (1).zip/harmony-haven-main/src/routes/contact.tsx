import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { useState } from "react";
import { Phone, MessageCircle, MapPin, Mail, Send } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Uma Acu Wellness" },
      { name: "description", content: "Visit our acupuncture clinic in MGR Nagar, Chennai. Call, WhatsApp, or send us a message." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    // Compose a WhatsApp message as a simple, working channel
    const text = `Hello, my name is ${form.name}.%0APhone: ${form.phone}%0AEmail: ${form.email}%0A%0A${form.message}`;
    window.open(`https://wa.me/918667563373?text=${text}`, "_blank");
    setSent(true);
  }

  const address = "No. 22/13, Sanjay Gandhi Street, MGR Nagar, Chennai - 600078";
  const mapsSrc = `https://www.google.com/maps?q=${encodeURIComponent(address)}&output=embed`;

  return (
    <SiteLayout>
      <section className="bg-gradient-hero py-20">
        <div className="container mx-auto px-5 lg:px-8 text-center max-w-3xl">
          <div className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">Get in Touch</div>
          <h1 className="mt-3 font-display text-5xl md:text-6xl font-semibold">Contact Us</h1>
          <p className="mt-4 text-muted-foreground">
            We're happy to help with appointments, questions, or directions.
          </p>
        </div>
      </section>

      <section className="container mx-auto px-5 lg:px-8 py-14 grid lg:grid-cols-2 gap-8">
        {/* Info */}
        <div className="space-y-5">
          <div className="rounded-3xl bg-card border border-border/60 p-7 shadow-card">
            <h3 className="font-display text-2xl font-semibold mb-4">Clinic Details</h3>
            <div className="space-y-4 text-sm">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                <span className="text-foreground/85">{address}</span>
              </div>
              <a href="tel:8667563373" className="flex items-start gap-3 hover:text-primary">
                <Phone className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                <span className="font-semibold">8667563373</span>
              </a>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <a href="tel:8667563373" className="inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-5 py-3 text-sm font-semibold shadow-soft hover:opacity-90">
                <Phone className="w-4 h-4" /> Call Now
              </a>
              <a href="https://wa.me/918667563373" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-[#25D366] text-white px-5 py-3 text-sm font-semibold shadow-soft hover:opacity-90">
                <MessageCircle className="w-4 h-4" /> WhatsApp
              </a>
            </div>
          </div>

          <div className="rounded-3xl overflow-hidden border border-border/60 shadow-card bg-card">
            <iframe
              title="Clinic location"
              src={mapsSrc}
              className="w-full h-72 border-0"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="rounded-3xl bg-card border border-border/60 p-7 md:p-8 shadow-card space-y-4">
          <h3 className="font-display text-2xl font-semibold flex items-center gap-2">
            <Mail className="w-5 h-5 text-primary" /> Send a Message
          </h3>

          <div>
            <label className="text-sm font-semibold">Name</label>
            <input
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="mt-1 w-full px-4 py-3 rounded-2xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-semibold">Phone</label>
              <input
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="mt-1 w-full px-4 py-3 rounded-2xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <div>
              <label className="text-sm font-semibold">Email</label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="mt-1 w-full px-4 py-3 rounded-2xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
          </div>
          <div>
            <label className="text-sm font-semibold">Message</label>
            <textarea
              required
              rows={5}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              className="mt-1 w-full px-4 py-3 rounded-2xl bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none"
            />
          </div>

          <button
            type="submit"
            className="inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-6 py-3.5 text-sm font-semibold shadow-soft hover:opacity-90 transition"
          >
            <Send className="w-4 h-4" /> Send via WhatsApp
          </button>

          {sent && (
            <div className="text-sm text-primary mt-2">Opening WhatsApp… thank you!</div>
          )}
        </form>
      </section>
    </SiteLayout>
  );
}
