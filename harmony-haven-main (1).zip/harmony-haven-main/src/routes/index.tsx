import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { Phone, Calendar, ClipboardList, MessageCircle, Sparkles, Heart, Leaf, ShieldCheck, Users, Star } from "lucide-react";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Uma Acu Wellness — Acupuncture Clinic in MGR Nagar, Chennai" },
      { name: "description", content: "Natural wellness through acu therapy. T. Uma Maheshwari, qualified Acu Therapist. Book your appointment today." },
    ],
  }),
  component: HomePage,
});

const testimonials = [
  { quote: "Very caring and peaceful treatment experience.", name: "Priya R." },
  { quote: "Good follow-up and clear explanation.", name: "Karthik S." },
  { quote: "Clinic atmosphere is calm and professional.", name: "Lakshmi V." },
];

const reasons = [
  { icon: Sparkles, title: "Experienced Acu Therapist", desc: "Years of practice in acupuncture & acu therapy." },
  { icon: Heart, title: "Pulse-based Checking", desc: "Traditional naadi assessment for each visit." },
  { icon: Users, title: "Question-based Consultation", desc: "Careful listening and personal attention." },
  { icon: Leaf, title: "Calm & Caring Approach", desc: "A warm, welcoming clinic atmosphere." },
  { icon: ShieldCheck, title: "Natural Wellness Support", desc: "Drug-free therapy focused on balance." },
  { icon: ClipboardList, title: "Patient-friendly Tracking", desc: "Check your sessions online anytime." },
];

function HomePage() {
  return (
    <SiteLayout>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-secondary/60 blur-3xl" />
        <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-accent/50 blur-3xl" />

        <div className="relative container mx-auto px-5 lg:px-8 pt-20 pb-24 lg:pt-28 lg:pb-32 text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-white/70 backdrop-blur px-4 py-1.5 text-xs font-semibold text-primary border border-primary/15 animate-fade-up">
            <Sparkles className="w-3.5 h-3.5" /> Acupuncture · Acu Therapy · Pulse Checking
          </div>

          <h1 className="mt-6 font-display text-5xl md:text-6xl lg:text-7xl font-semibold text-foreground leading-[1.05] animate-fade-up">
            Uma Acu Wellness
          </h1>
          <p className="mt-4 font-display text-2xl md:text-3xl text-primary italic animate-fade-up">
            Natural Wellness Through Acu Therapy
          </p>

          <div className="mt-8 max-w-2xl mx-auto animate-fade-up">
            <div className="inline-block rounded-2xl bg-white/80 backdrop-blur px-6 py-4 shadow-card border border-border/50">
              <div className="font-display text-xl font-semibold">T. Uma Maheshwari</div>
              <div className="text-sm text-muted-foreground mt-1">BBA, D.Ac., M.Sc., Acu Therapist</div>
            </div>
          </div>

          <div className="mt-10 flex flex-wrap justify-center gap-3 animate-fade-up">
            <a href="tel:8667563373" className="inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-6 py-3.5 text-sm font-semibold shadow-soft hover:opacity-90 transition">
              <Calendar className="w-4 h-4" /> Book Appointment
            </a>
            <a href="tel:8667563373" className="inline-flex items-center gap-2 rounded-full bg-gradient-gold text-gold-foreground px-6 py-3.5 text-sm font-semibold shadow-soft hover:opacity-90 transition">
              <Phone className="w-4 h-4" /> Call Now
            </a>
            <Link to="/track" className="inline-flex items-center gap-2 rounded-full bg-white text-foreground border border-border px-6 py-3.5 text-sm font-semibold hover:bg-secondary transition">
              <ClipboardList className="w-4 h-4" /> Track My Treatment
            </Link>
            <a href="https://wa.me/918667563373" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-[#25D366] text-white px-6 py-3.5 text-sm font-semibold shadow-soft hover:opacity-90 transition">
              <MessageCircle className="w-4 h-4" /> WhatsApp
            </a>
          </div>
        </div>
      </section>

      {/* Why choose us */}
      <section className="container mx-auto px-5 lg:px-8 py-20">
        <div className="text-center max-w-2xl mx-auto">
          <div className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">Why Choose Us</div>
          <h2 className="mt-3 font-display text-4xl md:text-5xl font-semibold">A gentle path to balance</h2>
          <p className="mt-4 text-muted-foreground">
            Personalized care rooted in traditional acu therapy practices.
          </p>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {reasons.map((r, i) => (
            <div key={i} className="group rounded-3xl bg-card border border-border/60 p-7 shadow-card hover:shadow-soft hover:-translate-y-1 transition-all">
              <div className="w-12 h-12 rounded-2xl bg-gradient-warm flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <r.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display text-xl font-semibold">{r.title}</h3>
              <p className="text-sm text-muted-foreground mt-2">{r.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-gradient-warm py-20">
        <div className="container mx-auto px-5 lg:px-8">
          <div className="text-center max-w-2xl mx-auto">
            <div className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">Testimonials</div>
            <h2 className="mt-3 font-display text-4xl md:text-5xl font-semibold">Kind words from patients</h2>
          </div>
          <TestimonialCarousel />
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-5 lg:px-8 py-20">
        <div className="rounded-3xl bg-gradient-hero border border-border/60 p-10 md:p-14 text-center shadow-soft">
          <h2 className="font-display text-4xl md:text-5xl font-semibold">Begin your wellness journey</h2>
          <p className="mt-3 text-muted-foreground max-w-xl mx-auto">
            Reach out to schedule a consultation. We'll guide you with care, every step of the way.
          </p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <a href="tel:8667563373" className="inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-6 py-3.5 text-sm font-semibold shadow-soft hover:opacity-90">
              <Phone className="w-4 h-4" /> Call 8667563373
            </a>
            <Link to="/contact" className="inline-flex items-center gap-2 rounded-full bg-white border border-border text-foreground px-6 py-3.5 text-sm font-semibold hover:bg-secondary">
              Visit Contact Page
            </Link>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}

function TestimonialCarousel() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setI((p) => (p + 1) % testimonials.length), 4500);
    return () => clearInterval(id);
  }, []);
  return (
    <div className="mt-12 max-w-2xl mx-auto">
      <div className="relative rounded-3xl bg-card border border-border/60 p-10 shadow-card text-center min-h-[200px]">
        <div className="flex justify-center gap-1 mb-4">
          {[...Array(5)].map((_, k) => (
            <Star key={k} className="w-4 h-4 fill-gold text-gold" style={{ color: "var(--gold)" }} />
          ))}
        </div>
        <p key={i} className="font-display text-2xl italic text-foreground animate-fade-up">
          “{testimonials[i].quote}”
        </p>
        <div className="mt-4 text-sm text-muted-foreground">— {testimonials[i].name}</div>
      </div>
      <div className="flex justify-center gap-2 mt-5">
        {testimonials.map((_, k) => (
          <button
            key={k}
            onClick={() => setI(k)}
            aria-label={`Go to testimonial ${k + 1}`}
            className={`h-2 rounded-full transition-all ${k === i ? "w-8 bg-primary" : "w-2 bg-border"}`}
          />
        ))}
      </div>
    </div>
  );
}
