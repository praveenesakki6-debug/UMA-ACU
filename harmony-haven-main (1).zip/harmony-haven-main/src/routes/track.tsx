import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { useState } from "react";
import { Search, User, Activity, Calendar, Layers, CheckCircle2, IndianRupee, Wallet, IdCard } from "lucide-react";

export const Route = createFileRoute("/track")({
  head: () => ({
    meta: [
      { title: "Track My Treatment — Uma Acu Wellness" },
      { name: "description", content: "Enter your Patient ID to view your treatment progress." },
    ],
  }),
  component: TrackPage,
});

const API_URL =
  "https://script.google.com/macros/s/AKfycby4NRhHv3LH2TQrIK-o9TT_krVv3RSZi3Cgeo5eCgmKFL5ooEApJIY7OS-ztM08aYZGQw/exec";

type PatientRecord = {
  patientName?: string;
  treatmentType?: string;
  totalSessionsPlanned?: number | string;
  currentSessionNumber?: number | string;
  sessionsCompleted?: number | string;
  nextVisitDate?: string;
  totalTreatmentAmount?: number | string;
  amountPaid?: number | string;
  patientId?: string;
};

function pick(obj: Record<string, unknown>, keys: string[]): string | number | undefined {
  for (const k of keys) {
    const found = Object.keys(obj).find((kk) => kk.toLowerCase().replace(/[\s_-]/g, "") === k.toLowerCase().replace(/[\s_-]/g, ""));
    if (found && obj[found] !== undefined && obj[found] !== "") return obj[found] as string | number;
  }
  return undefined;
}

function normalize(raw: Record<string, unknown>): PatientRecord {
  return {
    patientName: pick(raw, ["patientName", "name", "patient_name"]) as string | undefined,
    treatmentType: pick(raw, ["treatmentType", "treatment", "treatment_type"]) as string | undefined,
    totalSessionsPlanned: pick(raw, ["totalSessionsPlanned", "totalSessions", "sessionsPlanned"]),
    currentSessionNumber: pick(raw, ["currentSessionNumber", "currentSession"]),
    sessionsCompleted: pick(raw, ["sessionsCompleted", "completedSessions"]),
    nextVisitDate: pick(raw, ["nextVisitDate", "nextVisit", "next_visit_date"]) as string | undefined,
    totalTreatmentAmount: pick(raw, ["totalTreatmentAmount", "totalAmount", "treatmentAmount"]),
    amountPaid: pick(raw, ["amountPaid", "paidAmount", "paid"]),
    patientId: pick(raw, ["patientId", "id", "patient_id"]) as string | undefined,
  };
}

function TrackPage() {
  const [patientId, setPatientId] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [record, setRecord] = useState<PatientRecord | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const id = patientId.trim();
    if (!id) return;
    setLoading(true);
    setError(null);
    setNotFound(false);
    setRecord(null);
    try {
      const res = await fetch(`${API_URL}?patientId=${encodeURIComponent(id)}`);
      if (!res.ok) throw new Error("network");
      const json = await res.json();

      if (json && json.success === true) {
        // try `data`, `record`, `patient`, or root
        const raw = (json.data || json.record || json.patient || json) as Record<string, unknown>;
        const norm = normalize(raw);
        if (!norm.patientName && !norm.patientId && !norm.treatmentType) {
          setNotFound(true);
        } else {
          setRecord({ ...norm, patientId: norm.patientId || id });
        }
      } else {
        setNotFound(true);
      }
    } catch {
      setError("Something went wrong. Please try again later.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <SiteLayout>
      <section className="bg-gradient-hero py-20">
        <div className="container mx-auto px-5 lg:px-8 text-center max-w-3xl">
          <div className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">Patient Portal</div>
          <h1 className="mt-3 font-display text-5xl md:text-6xl font-semibold">Track My Treatment</h1>
          <p className="mt-4 text-muted-foreground">
            Enter your Patient ID to view your treatment progress.
          </p>
        </div>
      </section>

      <section className="container mx-auto px-5 lg:px-8 py-14 max-w-2xl">
        <form
          onSubmit={handleSubmit}
          className="rounded-3xl bg-card border border-border/60 p-7 md:p-8 shadow-card"
        >
          <label htmlFor="pid" className="block text-sm font-semibold mb-2">
            Patient ID
          </label>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <IdCard className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                id="pid"
                type="text"
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                placeholder="e.g. P1001"
                className="w-full pl-11 pr-4 py-3.5 rounded-full bg-background border border-input text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <button
              type="submit"
              disabled={loading || !patientId.trim()}
              className="inline-flex items-center justify-center gap-2 rounded-full bg-primary text-primary-foreground px-6 py-3.5 text-sm font-semibold shadow-soft hover:opacity-90 disabled:opacity-50 transition"
            >
              <Search className="w-4 h-4" /> View Details
            </button>
          </div>
        </form>

        <div className="mt-8">
          {loading && (
            <div className="rounded-2xl bg-secondary/50 border border-border/60 p-6 text-center text-foreground animate-fade-up">
              Checking your record…
            </div>
          )}
          {error && (
            <div className="rounded-2xl bg-destructive/10 border border-destructive/30 p-6 text-center text-destructive animate-fade-up">
              {error}
            </div>
          )}
          {notFound && !loading && (
            <div className="rounded-2xl bg-secondary/50 border border-border/60 p-6 text-center text-foreground animate-fade-up">
              No record found. Please check your Patient ID or contact the clinic.
            </div>
          )}
          {record && <RecordCard record={record} />}
        </div>
      </section>
    </SiteLayout>
  );
}

function RecordCard({ record }: { record: PatientRecord }) {
  const items = [
    { icon: User, label: "Patient Name", value: record.patientName },
    { icon: Activity, label: "Treatment Type", value: record.treatmentType },
    { icon: Layers, label: "Total Sessions Planned", value: record.totalSessionsPlanned },
    { icon: CheckCircle2, label: "Current Session Number", value: record.currentSessionNumber },
    { icon: CheckCircle2, label: "Sessions Completed", value: record.sessionsCompleted },
    { icon: Calendar, label: "Next Visit Date", value: record.nextVisitDate },
    { icon: IndianRupee, label: "Total Treatment Amount", value: record.totalTreatmentAmount },
    { icon: Wallet, label: "Amount Paid", value: record.amountPaid },
    { icon: IdCard, label: "Patient ID", value: record.patientId },
  ];

  return (
    <div className="rounded-3xl bg-card border border-border/60 p-7 md:p-8 shadow-card animate-fade-up">
      <div className="text-center pb-5 border-b border-border/60">
        <div className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">Treatment Record</div>
        <h3 className="mt-2 font-display text-3xl font-semibold">{record.patientName || "Patient"}</h3>
      </div>
      <dl className="mt-6 grid sm:grid-cols-2 gap-4">
        {items.map((it, i) => (
          <div key={i} className="flex items-start gap-3 rounded-2xl bg-gradient-warm p-4">
            <div className="w-9 h-9 rounded-xl bg-white/80 flex items-center justify-center shrink-0">
              <it.icon className="w-4 h-4 text-primary" />
            </div>
            <div className="min-w-0">
              <dt className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold">{it.label}</dt>
              <dd className="text-sm font-semibold text-foreground mt-0.5 break-words">
                {it.value !== undefined && it.value !== "" ? String(it.value) : "—"}
              </dd>
            </div>
          </div>
        ))}
      </dl>
    </div>
  );
}
